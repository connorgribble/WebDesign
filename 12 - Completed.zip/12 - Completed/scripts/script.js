/*
	Student Name: Connor Gribble
	File Name: script.js
	Date: 04/20/2025
*/

//jQuery for hero image to consume the header window space
 $(document).ready(function(){
		$('.hero'). height($(window).height());
 });